<!DOCTYPE html>
<html lang="en">
<head>
<title>Ankit Koshti | Software Developer</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="ankit, Ankit, koshtiankit, Php, html, Angular, Ajax, php developer" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--// Meta tag Keywords -->
<!-- css files -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /> <!-- Bootstrap-Core-CSS -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /> <!-- Style-CSS --> 

 <!-- Font-Awesome-Icons-CSS -->
 <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="css/cm-overlay.css" />
<!-- //css files -->

<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Josefin+Sans:100,100i,300,300i,400,400i,600,600i,700,700i&amp;subset=latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
<!-- //online-fonts -->
</head>
<body> 
<!-- banner -->
<div id="home" class="banner">
	<div class="banner-agileinfo">
		<!-- header -->
		<div class="header">
			<div class="container">		
				<div class="logo">
					<h1><a href="#">Ankit Koshti</a></h1>
				</div> 
				<div class="menu">
					<a href="" id="menuToggle"> <span class="navClosed"></span> </a>
					<nav>  
						<a href="index.html" class="active">Home</a> 
						<a href="#about" class="scroll">About Me</a>  
						<a href="#skills" class="scroll">My Skills</a>  
						<!-- <a href="#services" class="scroll">My Services</a> -->
						<a href="#experience" class="scroll">Experience</a> 
						<a href="#education" class="scroll">My Education</a> 
						<!-- <a href="#projects" class="scroll">My Projects</a> -->
						<a href="#contact" class="scroll">Contact Me</a> 
					</nav>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<!-- //header -->
		<div class="banner-main">
			<div class="container">	
				<div class="col-md-5 banner-left">
					<!-- <img src="images/ankit-koshti-web-developer.png" alt="ankit-koshti-web-developer"> --> 
				</div>
				<div class="col-md-7 banner-text">
					<p>Welcome</p>
					<h2><span>I am Ankit Koshti</span> Web Developer</h2>
					<div class="w3agile_hire_right">
						<a href="#contact" class="wthree-more w3more1 nina scroll" data-text="hire me"> 
							<span>h</span><span>i</span><span>r</span><span>e</span> <span>m</span><span>e</span>
						</a> 
					</div>
				</div>
			</div> 
		</div>
	</div>
</div>
<!-- //banner -->
<!-- about -->
<div class="about" id="about">
	<div class="container">
		<h3 class="w3l-title">My Self</h3>
		<div class="about-w3l-agileifo-grid">
			<div class="col-md-7 agile-w3l-ab">
				<!-- <ul class="rslides" id="slider"> -->
					<ul class="rslides">
					<li>
						<div class="agile-w3l-ab-img">
							<h2 style="line-height: 50px; margin-bottom: 121px; margin-top: 104px">Learning continuously and welcoming new challenges makes me potential to grow further &amp; "positive thinker", "can-do" attitude these are my abilities.</h2>
							<!-- <img src="images/ankit-koshti-web-developer.png" class="img-responsive" alt="Homey Designs"> -->
						</div>
					</li>
					<li>
						<div class="agile-w3l-ab-img">
							<!-- <img src="images/a2.jpg" class="img-responsive" alt="Homey Designs"> -->
						</div>
					</li>
					<li>
						<div class="agile-w3l-ab-img">
							<!-- <img src="images/a1.jpg" class="img-responsive" alt="Homey Designs"> -->
						</div>
					</li>
				</ul>
			</div>
			<div class="col-md-5 w3ls-agile-left">
				<div class="w3ls-agile-left-info">
					<h4>Name</h4>
					<p>Ankit Koshti</p>
				</div>
				<div class="w3ls-agile-left-info">
					<h4>Sex</h4>
					<p>Male</p>
				</div>
				<div class="w3ls-agile-left-info">
					<h4>Address</h4>
					<p>Ahmedabad Gujarat-380024.</p>
				</div>
				<div class="w3ls-agile-left-info">
					<h4>Phone Number</h4>
					<p>+91 7048650657</p>
				</div>
				<div class="w3ls-agile-left-info">
					<h4>Email Address</h4>
					<p><a href="mailto:ankit15595@gmail.com">ankit15595@gmail.com</a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- //about -->
<!-- stats -->
<div class="stats wthree-sub" id="skills">
	<div class="container"> 
		<h3 class="w3l-title" style="color: #fff;">My Skills</h3>
		
		<div class="agile-w3l-in">
			<i class="fab fa-angular" aria-hidden="true"></i>
			<p>Angular</p>
		</div>
		<div class="agile-w3l-in">
			<i class="fab fa-laravel" aria-hidden="true"></i>
			<p>Laravel</p>
		</div>
		<div class="agile-w3l-in">
			<i class="fab fa-php" aria-hidden="true"></i>
			<p>php</p>
		</div>
		<div class="agile-w3l-in w3l-intra-re">
			<i class="fab fa-html5" aria-hidden="true"></i>
			<p>HTML</p>
		</div>
		<div class="agile-w3l-in w3l-intra-re">
			<i class="fab fa-css3-alt" aria-hidden="true"></i>
			<p>CSS</p>
		</div>
		<div class="clearfix"> </div>
	</div> 
</div>
<!-- //stats --> 
<!-- services --> 
<!-- <div class="services" id="services">
	<div class="container">
		<h3 class="w3l-title">My Services</h3>
		<div class="box2">
			<div class="col-sm-4 s-1">
				<a href="#">
					<div class="view view-fifth">
						<i class="fa fa-laptop" aria-hidden="true"></i>
						<div class="mask">
							<i class="fa fa-laptop" aria-hidden="true"></i>
							<h4>Web Design</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
						<h3>Web Design </h3>
					</div>
				</a>
			</div>
			<div class="col-sm-4 s-1">
				<a href="#">
					<div class="view view-fifth">
						<i class="fa fa-clone" aria-hidden="true"></i>
						<div class="mask">
							<i class="fa fa-clone" aria-hidden="true"></i>
							<h4>Creative Design</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
						<h3>Creative Design</h3>
					</div>
				</a>
			</div>
			<div class="col-sm-4 s-1">
				<a href="#">
					<div class="view view-fifth">
						<i class="fa fa-pencil" aria-hidden="true"></i>
						<div class="mask">
							<i class="fa fa-pencil" aria-hidden="true"></i>
							<h4>Html Coding</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
						</div>
						<h3>Html Coding</h3>
					</div>
				</a>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</div> -->
<!-- //services --> 
<!-- interests --> 
<!-- <div class="intra-w3l">
	<div class="container">
		<h3 class="w3l-title">Interests</h3>
		<div class="agile-w3l-in">
			<i class="fa fa-camera" aria-hidden="true"></i>
			<p>PHOTOGRAPHY</p>
		</div>
		<div class="agile-w3l-in">
			<i class="fa fa-plane" aria-hidden="true"></i>
			<p>TRAVELLING</p>
		</div>
		<div class="agile-w3l-in">
			<i class="fa fa-book" aria-hidden="true"></i>
			<p>Reading</p>
		</div>
		<div class="agile-w3l-in w3l-intra-re">
			<i class="fa fa-gamepad" aria-hidden="true"></i>
			<p>GAMING</p>
		</div>
		<div class="agile-w3l-in w3l-intra-re">
			<i class="fa fa-music" aria-hidden="true"></i>
			<p>MUSIC</p>
		</div>
	
	</div>
</div> -->
<!-- //interests --> 
<!-- experience -->
<div class="services-w3l" id="experience">
	<div class="container">
		<h3 class="w3l-title">Work Experience</h3>
		<div class="wthree_latest_albums_grids">
			<div class="cntl"> <span class="cntl-bar cntl-center"> <span class="cntl-bar-fill"></span> </span>
				<div class="cntl-states">
					<div class="cntl-state">
						<div class="cntl-content">
							<h4>June 2017 – Present 2018</h4>
							<p>Ikigai Infotech LLP (SalesHandy)</p>
						</div>
						<div class="cntl-image">
							<!-- <img src="images/w1.jpg" alt=" " class="img-responsive" /> -->
							<div class="w3ls_cntl_image_pos">
								<p>Software Developer</p>
							</div>
						</div>
						<div class="cntl-icon cntl-center">01</div>
					</div>
					<div class="cntl-state">
						<div class="cntl-content">
							<h4>October 2015 – May 2017</h4>
							<p>SSB Digital PVT LTD</p>
						</div>
						<div class="cntl-image">
                        <!-- <img src="images/w2.jpg" alt=" " class="img-responsive" /> -->
                            <div class="w3ls_cntl_image_pos">
                            <p>Web Developer</p>
                            </div>
                        </div>
						<div class="cntl-icon cntl-center">02</div>
					</div>
					<!-- <div class="cntl-state">
						<div class="cntl-content">
							<h4>2010 to 2013</h4>
							<p>Microsoft & IT Solutions</p>
						</div>
						<div class="cntl-image">
							<img src="images/w3.jpg" alt=" " class="img-responsive" />
							<div class="w3ls_cntl_image_pos">
								<p>Sed do eiusmod tempor incididunt et dolore magna aliqua.</p>
							</div>
						</div>
						<div class="cntl-icon cntl-center">03</div>
					</div>
					<div class="cntl-state">
						<div class="cntl-content">
							<h4>2007 to 2010</h4>
							<p>WebStyle Technologies</p>
						</div>
						<div class="cntl-image">
							<img src="images/w4.jpg" alt=" " class="img-responsive" />
							<div class="w3ls_cntl_image_pos">
								<p>Sed do eiusmod tempor incididunt et dolore magna aliqua.</p>
							</div>
						</div>
						<div class="cntl-icon cntl-center">04</div>
					</div> -->
				</div>
			</div>
		</div>
	</div>
</div>
<!-- //experience -->
<!-- education -->
<div class="experience" id="education">
	<div class="container">
		<h3 class="w3l-title" style="color: #fff;">My Education</h3>
		<div class="col-md-12 abt-left">
			<div class="accordion">
				<div class="accordion-section">
					<h5><a class="accordion-section-title" href="#accordion-1">
						<span>2011 - 2014</span> Diploma in Information Technology
					<i class="glyphicon glyphicon-chevron-down"></i>
					</a></h5>
					<div id="accordion-1" class="accordion-section-content">
						<h6>From Government Poly Himatnagar.</h6>
						<ul>
							<li><span class="glyphicon glyphicon-arrow-right" aria-hidden="true"></span><a href="#">with 7.23 SPI [GTU]</a></li>
							
						</ul>
					</div>
				</div>
				<div class="accordion-section">
					<h5><a class="accordion-section-title" href="#accordion-2">
						<span>2010</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;10th class
					<i class="glyphicon glyphicon-chevron-down"></i>
					</a></h5>
					<div id="accordion-2" class="accordion-section-content">
						
						<h6>From Jivan Sashna H.S School ahmedabad.</h6>
						<ul>
							<li><span class="glyphicon glyphicon-star" aria-hidden="true"></span><a href="#">with 73.08% [SSC]</a></li>
							<!-- <li><span class="glyphicon glyphicon-star" aria-hidden="true"></span><a href="#">accusantium doloremque</a></li>
							<li><span class="glyphicon glyphicon-star" aria-hidden="true"></span><a href="#">doloremque lauda loigfgf ntium</a></li> -->
						</ul>
					</div>
				</div>
				<!-- <div class="accordion-section">
					<h5><a class="accordion-section-title" href="#accordion-3">
						<span>1990 - 2000</span> Fedrick School
					<i class="glyphicon glyphicon-chevron-down"></i>
					</a></h5>
					<div id="accordion-3" class="accordion-section-content">
						<h6>Competitions</h6>
						<ul>
							<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">voluptatem accusantium</a></li>
							<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">Integer sodales, odio sit amet viverra sollicitudin</a></li>
							<li><span class="glyphicon glyphicon-ok" aria-hidden="true"></span><a href="#">onec pulvinar vestibulum sem quis porttitor</a></li>
						</ul>
					</div>
				</div> -->
			</div>
		</div>
	</div>
</div>
<!-- //education -->
<!-- projects -->
<!-- <div class="portfolio" id="projects">
	<div class="container">
		<h3 class="w3l-title">My Projects</h3>
		<div class="agileits_portfolio_grids">
			<div class="col-md-3 agileits_portfolio_grid">
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g1.jpg">
						<img src="images/g1.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g2.jpg">
						<img src="images/g2.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g3.jpg">
						<img src="images/g3.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-3 agileits_portfolio_grid">
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g4.jpg">
						<img src="images/g4.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g5.jpg">
						<img src="images/g5.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4> 
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g6.jpg">
						<img src="images/g6.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-3 agileits_portfolio_grid">
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g7.jpg">
						<img src="images/g7.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g8.jpg">
						<img src="images/g8.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g9.jpg">
						<img src="images/g9.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
			</div>
			<div class="col-md-3 agileits_portfolio_grid">
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g10.jpg">
						<img src="images/g10.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g11.jpg">
						<img src="images/g11.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4>
						</div>
					</a>
				</div>
				<div class="agileinfo_portfolio_grid hovereffect">
					<a class="cm-overlay" href="images/g12.jpg">
						<img src="images/g12.jpg" alt=" " class="img-responsive">
						<div class="overlay">
							<h4>Classic CV</h4> 
						</div>
					</a>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div> -->
<!-- //projects -->
<!-- introduce -->
<div class="confi-w3l">
	<div class="container">
		<h3>Hello....</h3>
		<p>It's my pleasure to introduce my self..well, I'm Ankit koshti and raised in India.</p>
		<p>My strengths are my attitude that i like to take challenges that I CAN do it,my way of thinking that i take both success and failure in a balanced manner..</p>
	</div>
</div>
<!-- //introduce -->
<!-- //contact -->
<div class="address" id="contact">
	<div class="container">
		<h3 class="w3l-title" style="margin-bottom: 0.3em;">Contact Me</h3>
		<div class="address-row">
			<div class="col-md-6 address-left wow agile fadeInLeft animated" data-wow-delay=".5s">
				<div class="address-grid">
					<h4 class="wow fadeIndown animated" data-wow-delay=".5s">Get In Touch</h4>
					<form action="#" method="post">
						<input type="text" placeholder="Name" name="name" required="">
						<input type="email" placeholder="Email" name="email" required="">
						<input type="text" placeholder="Subject" name="subject" required="">
						<textarea placeholder="Message" required=""></textarea>
						<input type="submit" value="SEND">
					</form>
				</div>
			</div>
			<div class="col-md-6 address-right">
				<div class="address-info wow fadeInRight animated" data-wow-delay=".5s">
					<h4>Address</h4>
					<p>Ahmedabad India Gujarat-380024.</p>
				</div>
				<div class="address-info address-mdl wow fadeInRight animated" data-wow-delay=".7s">
					<h4>Phone </h4>
					<p>+91 70486560657</p>
				</div>
				<div class="address-info agileits-info wow fadeInRight animated" data-wow-delay=".6s">
					<h4>Mail</h4>
					<p><a href="mailto:ankit15595@gmail.com"> ankit15595@gmail.com</a></p>
				</div>
			</div>
		</div>	
	</div>	
</div>
<!--//contact-->
<!-- footer -->
<div class="footer w3ls">
	<div class="container">
	<link rel="stylesheet" href="css/font-awesome.css">
		<div class="w3ls-social-icons-2">
			<a class="facebook" href="https://www.facebook.com/ankit.koshti.007"><i class="fa fa-facebook" aria-hidden="true"></i></a>
			<!-- <a class="twitter" href="#"><i class="fa fa-twitter"></i></a> -->
			<a class="pinterest" href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
			<a class="linkedin" href="https://in.linkedin.com/in/ankit-koshti-web-developer"><i class="fa fa-linkedin"></i></a>
			<a class="tumblr" href="https://medium.com/@ankit.koshti/"><i class="fa fa-medium" aria-hidden="true"></i></a>
		</div>
	</div>
</div>
<div class="copyrights">
	<a href="http://w3layouts.com">W3layouts</a>
</div>
<!-- //footer -->

<!-- js-scripts -->		
<!-- js -->


<script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
<!-- <script type="text/javascript" src="js/jquery.js"></script> -->
<script type="text/javascript" src="js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
<!-- //js -->
	
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
        });
	});
    
</script>
<!-- start-smoth-scrolling -->
<script src="js/SmoothScroll.min.js"></script>
<!-- for-bottom-to-top smooth scrolling -->
<script type="text/javascript">
	$(document).ready(function() {
	/*
		var defaults = {
		containerID: 'toTop', // fading element id
		containerHoverID: 'toTopHover', // fading element hover id
		scrollSpeed: 1200,
		easingType: 'linear' 
		};
	*/								
	$().UItoTop({ easingType: 'easeOutQuart' });
	});
</script>
<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //for-bottom-to-top smooth scrolling -->
<!-- menu-script -->
<script>
	(function($){
		// Menu Functions
		$(document).ready(function(){
		$('#menuToggle').click(function(e){
			var $parent = $(this).parent('.menu');
		  $parent.toggleClass("open");
		  var navState = $parent.hasClass('open') ? "hide" : "show";
		  $(this).attr("title", navState + " navigation");
				// Set the timeout to the animation length in the CSS.
				setTimeout(function(){
					console.log("timeout set");
					$('#menuToggle > span').toggleClass("navClosed").toggleClass("navOpen");
				}, 200);
			e.preventDefault();
		});
	  });
	})(jQuery);
</script>
<!-- //menu-script -->
<!-- baneer-js -->
<script src="js/responsiveslides.min.js"></script>
<script>
	// You can also use "$(window).load(function() {"
	$(function () {
	  // Slideshow 4
	  $("#slider").responsiveSlides({
		auto: true,
		pager:false,
		nav:false,
		speed: 500,
		namespace: "callbacks",
		before: function () {
		  $('.events').append("<li>before event fired.</li>");
		},
		after: function () {
		  $('.events').append("<li>after event fired.</li>");
		}
	  });

	});
</script>				 
<!-- //baneer-js -->
<!-- skills -->
<script src="js/skill.bars.jquery.js"></script>
<script>
	$(document).ready(function(){
		
		$('.skillbar').skillBars({
			from: 0,
			speed: 4000, 
			interval: 100,
			decimals: 0,
		});
		
	});
</script>
<!-- //skills --> 
<!-- timeline -->
<script type="text/javascript" src="js/jquery.cntl.js"></script> 
<script type="text/javascript">
	$(document).ready(function(e){
		$('.cntl').cntl({
			revealbefore: 300,
			anim_class: 'cntl-animate',
			onreveal: function(e){
				console.log(e);
			}
		});
	});
</script>
<!-- //timeline -->
<!-- accordion -->
<script>
	jQuery(document).ready(function() {
	function close_accordion_section() {
		jQuery('.accordion .accordion-section-title').removeClass('active');
		jQuery('.accordion .accordion-section-content').slideUp(300).removeClass('open');
	}

	jQuery('.accordion-section-title').click(function(e) {
		// Grab current anchor value
		var currentAttrValue = jQuery(this).attr('href');

		if(jQuery(e.target).is('.active')) {
			close_accordion_section();
		}else {
			close_accordion_section();

			// Add active class to section title
			jQuery(this).addClass('active');
			// Open up the hidden content panel
			jQuery('.accordion ' + currentAttrValue).slideDown(300).addClass('open'); 
		}

		e.preventDefault();
	});
	});
</script>
<!-- //accordion -->
<!-- for projects -->
<script src="js/jquery.tools.min.js"></script>
<script src="js/jquery.mobile.custom.min.js"></script>
<script src="js/jquery.cm-overlay.js"></script>
<script>
	$(document).ready(function(){
		$('.cm-overlay').cmOverlay();
	});
</script>
<!-- //for projects -->				
<!-- smooth scrolling -->
<!-- <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script> -->

<!-- //smooth scrolling -->
<!-- //js-scripts -->

</body>
</html>